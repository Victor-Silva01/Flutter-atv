package com.example.flutter001

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
