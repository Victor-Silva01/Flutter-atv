import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'TabBar App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: TabBarScreen(),
    );
  }
}

class TabBarScreen extends StatefulWidget {
  @override
  _TabBarScreenState createState() => _TabBarScreenState();
}

class _TabBarScreenState extends State<TabBarScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('TabBar App'),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          Center(
            child: Text('Bem- Vindo a Tela Inicial'),
          ),
          Center(
            child: Text('Bem-Vindo a Tela Perfil'),
          ),
        ],
      ),
      bottomNavigationBar: TabBar(
        controller: _tabController,
        tabs: [
          Tab(
            text: 'Início',
            icon: Icon(Icons.home),
          ),
          Tab(
            text: 'Perfil',
            icon: Icon(Icons.person),
          ),
        ],
        indicatorColor: Colors.red, 
        unselectedLabelColor: Colors.black, 
      ),
    );
  }
}
