import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Color.fromARGB(255, 132, 8, 8)),
        useMaterial3: true,
      ),
      home: Scaffold(
        appBar: AppBar(
          backgroundColor: Color.fromARGB(255, 52, 235, 255), 
          title: const Text(
            'Flutter Demo Home Page',
            style: TextStyle(
              color: Color.fromARGB(255, 76, 226, 249), 
            ),
          ),
        ),
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center, 
          children: <Widget>[
            SizedBox(height: 6),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 6),
              child: Text(
                'Tenha um dia feliz',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  fontStyle: FontStyle.italic,
                  color: Color.fromARGB(255, 0, 0, 0),
                ),
              ),
            ),
            const SizedBox(height: 20),
            Center(
              child: Container(
                width: 200,
                height: 100,
                color: Colors.red, 
              ),
            ),
            const SizedBox(height: 20),
            Center(
              child: Icon(
                Icons.sentiment_satisfied_alt,
                size: 110,
                color: Colors.blue,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
